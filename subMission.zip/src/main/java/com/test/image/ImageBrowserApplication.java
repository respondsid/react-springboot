package com.test.image;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageBrowserApplication {
	static {
		System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", "10");
	}

	public static void main(String[] args) {
		SpringApplication.run(ImageBrowserApplication.class, args);
	}

}
