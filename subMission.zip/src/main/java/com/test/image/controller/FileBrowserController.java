package com.test.image.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.image.model.FileItem;
import com.test.image.service.FileBrowserService;

@RestController
@RequestMapping("api")
public class FileBrowserController {

	@Autowired
	FileBrowserService browserService;

	@RequestMapping(value = "/files", method = RequestMethod.GET)
	public FileItem getFiles() throws IOException {
		return browserService.returnDirectoryInformation("test");
	}

	@RequestMapping(value = "/files/download", method = RequestMethod.GET, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public void downloadFile(@RequestParam("path") String path, HttpServletResponse response) throws IOException {
		File file= new File(path);
		FileInputStream imgFile = new FileInputStream(file);
		StreamUtils.copy(imgFile, response.getOutputStream());
	}
}
