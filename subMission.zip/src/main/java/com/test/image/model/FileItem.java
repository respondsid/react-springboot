package com.test.image.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
@JsonInclude(Include.NON_NULL)
@Builder
public class FileItem {
	private String name;
	private String type;
	private String path;
	private Long size;
	private List<FileItem> items;
	private ImageInfo image;
	private boolean error;
	
}
