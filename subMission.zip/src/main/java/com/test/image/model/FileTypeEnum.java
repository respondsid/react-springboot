package com.test.image.model;

public enum FileTypeEnum {
	FILE("file"), FOLDER("folder");
	private String type;

	private FileTypeEnum(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}
}
