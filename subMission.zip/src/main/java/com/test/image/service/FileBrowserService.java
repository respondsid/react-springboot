package com.test.image.service;

import java.io.IOException;

import com.test.image.model.FileItem;

public interface FileBrowserService {
	public FileItem returnDirectoryInformation(String dirLocation) throws IOException;
}
