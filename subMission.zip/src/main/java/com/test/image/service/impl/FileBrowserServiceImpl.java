package com.test.image.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.test.image.model.FileItem;
import com.test.image.model.FileTypeEnum;
import com.test.image.model.ImageInfo;
import com.test.image.service.FileBrowserService;
import com.test.image.utils.ImageUtils;

import lombok.extern.slf4j.Slf4j;

// TODO: Auto-generated Javadoc
/**
 * The Class FileBrowserServiceImpl.
 */
@Component

/** The Constant log. */

/** The Constant log. */
@Slf4j
public class FileBrowserServiceImpl implements FileBrowserService {

	/** The input dir. */
	@Value("${test.input.dir}")
	private String inputDir;

	/** The ignore list. */
	@Value("${test.includeFiles.regex}")
	private String includeListRegex;

	/** The include file pattern. */
	Pattern includeFilePattern;

	FileItem rootItem;

	/**
	 * Initialize pattern.
	 * 
	 * @throws IOException
	 */
	@PostConstruct
	public void initializePattern() throws IOException {
		Assert.notNull(includeListRegex,
				"Include extensions regex pattern is null or invalid please check application.properties proprty 'test.includeFiles.regex'");
		includeFilePattern = Pattern.compile(includeListRegex);
		cacheDirectory();
	}

	private void cacheDirectory() throws IOException {
		Assert.notNull(inputDir, "Input director is null!!!");
		File file = new File(inputDir);
		Assert.isTrue(file.exists(), "Input director doesnt exist !! please check " + inputDir);
		rootItem = browseFileSystem("", file);
	}

	/**
	 * Return directory information.
	 *
	 * @param dirLocation the dir location
	 * @return the file item
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Override
	public FileItem returnDirectoryInformation(String dirLocation) throws IOException {
		return rootItem;
	}

	/**
	 * Browse file system.
	 *
	 * @param prevPath the prev path
	 * @param file     the file
	 * @return the file item
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private FileItem browseFileSystem(String prevPath, File file) throws IOException {
		if (file.isFile() && !includeFilePattern.matcher(file.getName().toLowerCase()).matches()) {
			log.info("Filename {} ignored", file.getName());
			return null;
		}
		FileTypeEnum type = file.isFile() ? FileTypeEnum.FILE : FileTypeEnum.FOLDER;
		List<FileItem> fileItems = null;
		ImageInfo imageInfo = null;
		boolean thumbnailError = false;
		if (file.isDirectory()) {
			fileItems = populateSubDirectories(prevPath, file);
		} else {
			try {
				imageInfo = generateThumbNailInfo(file);
			} catch (Exception ex) {
				log.error("Exception generating thumbnail for image {}", file.getPath());
				thumbnailError = true;
			}
		}
		return FileItem.builder()
					   .name(file.getName())
					   .type(type.getType())
					   .path(prevPath + file.getName())
					   .size(file.isFile() ? file.length() : null)
					   .image(imageInfo)
					   .items(fileItems).error(thumbnailError)
				.build();
	}

	/**
	 * Populate sub directories.in a parallel stream
	 *
	 * @param prevPath the prev path
	 * @param file     the file
	 * @return the list
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private List<FileItem> populateSubDirectories(String prevPath, File file) throws IOException {
		if (file.isDirectory()) {
			List<FileItem> fileItems = new ArrayList<FileItem>();
			Arrays.asList(file.listFiles()).parallelStream().forEach(f -> {
				FileItem temp;
				try {
					temp = browseFileSystem(prevPath + file.getName() + "/", f);
				} catch (IOException e) {
					throw new UncheckedIOException(e);
				}
				if (temp != null) {
					fileItems.add(temp);
				}

			});
			return fileItems;
		}
		return null;
	}

	/**
	 * Generate thumb nail.
	 *
	 * @param file the file
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private ImageInfo generateThumbNailInfo(File file) throws IOException {
		return ImageUtils.constructImageInfo(file);
	}

}
