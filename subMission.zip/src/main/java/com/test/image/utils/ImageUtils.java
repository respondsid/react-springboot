package com.test.image.utils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;

import com.test.image.model.ImageInfo;

import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;

// TODO: Auto-generated Javadoc

@Slf4j
public class ImageUtils {

	/**
	 * Encode to string.
	 *
	 * @param image the image
	 * @param type  the type
	 * @param info  the info
	 * @return the string
	 */
	public static void populateThumbnailImageInfo(BufferedImage image, String type, ImageInfo info) {
		String imageString = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		try {
			ImageIO.write(image, type, bos);
			byte[] imageBytes = bos.toByteArray();
			imageString = Base64.getEncoder().encodeToString(imageBytes);
			info.setBase64String(imageString);
			info.setLandscape(image.getWidth() > image.getHeight());
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		} finally {
			try {
				bos.close();
			} catch (IOException e) {
				throw new UncheckedIOException(e);
			}
		}
	}

	/**
	 * Generate thumbnail.
	 *
	 * @param file the file
	 * @param info the info
	 * @return the string
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private static void populateThumbnail(File file, ImageInfo info) throws IOException {
		BufferedImage originalImage = ImageIO.read(file);
		BufferedImage thumbnail = Thumbnails.of(originalImage).size(256, 256).asBufferedImage();
		populateThumbnailImageInfo(thumbnail, getFileType(file), info);
	}

	/**
	 * Construct image info.
	 *
	 * @param file the file
	 * @return the image info
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static ImageInfo constructImageInfo(File file) throws IOException {
		ImageInfo info = new ImageInfo();
		BufferedImage originalImage = ImageIO.read(file);
		populateThumbnail(file, info);
		populateOtherImageInfo(file, originalImage, info, getFileType(file));
		return info;

	}

	/**
	 * Populate other image info.
	 *
	 * @param file          the file
	 * @param originalImage the original image
	 * @param info          the info
	 * @param fileType      the file type
	 * @throws IOException 
	 */
	private static void populateOtherImageInfo(File file, BufferedImage originalImage, ImageInfo info, String fileType) throws IOException {
		info.setHeight(originalImage.getHeight());
		info.setWidth(originalImage.getWidth());
		info.setHash256(generateHash(file, info, fileType));
	}

	/**
	 * Generate hash.
	 *
	 * @param file     the file
	 * @param info     the info
	 * @param fileType the file type
	 * @return the string
	 * @throws IOException 
	 */
	private static String generateHash(File file, ImageInfo info, String fileType) throws IOException {
		byte[] imageBytes = convertFileToByteArray(file, fileType);
		return DigestUtils.sha256Hex(imageBytes);
	}

	/**
	 * Gets the file type.
	 *
	 * @param file the file
	 * @return the file type
	 */
	private static String getFileType(File file) {
		return FilenameUtils.getExtension(file.getName()).toLowerCase();
	}

	/**
	 * Convert file to byte array.
	 *
	 * @param file the file
	 * @param type the type
	 * @return the byte[]
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private static byte[] convertFileToByteArray(File file, String type) throws IOException {
		BufferedImage bImage = ImageIO.read(file);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			ImageIO.write(bImage, type, bos);
			return bos.toByteArray();
		} finally {
			bos.close();
		}
	}

}
